import xbmc


xbmc.log('MICHS YOUTUBELIBRARY plugin.video.youtubelibrary: SERVICE.py started!')
xbmc.executebuiltin('RunPlugin(plugin://plugin.video.youtubelibrary/?mode=service)')