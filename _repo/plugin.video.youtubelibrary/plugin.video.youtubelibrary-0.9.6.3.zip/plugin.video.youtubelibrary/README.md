# plugin.video.youtubelibrary

Youtubelibrary is a Kodi addon enabling you to add YT playlists to your library as if it were tv shows!

For more information please visit:
http://forum.kodi.tv/showthread.php?tid=246110
